<?php
defined( 'ABSPATH' ) || exit;

final class PDS_Privacy {
    public static function boot() {
        add_filter( 'wp_privacy_personal_data_exporters', static function ( $exporters ) {
            $exporters['pds'] = array( 'exporter_friendly_name' => 'Portal de Serviços', 'callback' => array( __CLASS__, 'export' ) ); return $exporters;
        } );
        add_filter( 'wp_privacy_personal_data_erasers', static function ( $erasers ) {
            $erasers['pds'] = array( 'eraser_friendly_name' => 'Portal de Serviços', 'callback' => array( __CLASS__, 'erase' ) ); return $erasers;
        } );
        add_action( 'delete_user', array( __CLASS__, 'delete_user' ) );
        add_action( 'admin_init', static function () {
            if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
                wp_add_privacy_policy_content( 'Portal de Serviços', '<p>O portal usa a conta WordPress (nome, e-mail, senha protegida e cookies de autenticação). O serviço Meu Combustível armazena veículos, placa opcional, quilometragem, abastecimentos, valores e observações. Meu Financeiro armazena contas, saldos iniciais, transferências internas e estornos, contas a pagar, recorrências e recebimentos previstos ou realizados, cartões (apenas nome e quatro últimos dígitos opcionais), regras de fechamento/vencimento, faturas, parcelas e pagamentos. Abastecimentos novos geram gastos para quem os registra; dados de pagamento particulares não são compartilhados com participantes de veículos. CSV/OFX de fatura são lidos no servidor; PDFs de até 8 MB só são enviados ao Gemini mediante autorização na tela de importação. Confira os dados extraídos antes de importar. Prévias de importação expiram em 30 minutos e o arquivo original não é guardado pelo plugin. O serviço também armazena despesas pessoais em reais, categorias, datas, descrições, valores, formas de pagamento, estabelecimentos e observações, sempre vinculados à conta WordPress. O proprietário pode compartilhar um veículo com outras contas cadastradas; os participantes passam a visualizar seus abastecimentos. Limites de tentativas usam identificadores criptográficos temporários, apagados periodicamente. Os dados do aplicativo ficam no banco deste site. A consulta de atualizações conecta o servidor ao GitHub e envia a versão do plugin, sem enviar usuários, veículos ou abastecimentos. Recuperação de senha utiliza o e-mail do WordPress. A importação administrativa vincula IDs antigos às contas WordPress; a preparação dos backups expira após uma hora sem processamento e seu conteúdo é removido ao concluir a importação. O vínculo opcional com o Telegram associa o ID da conta ao usuário WordPress. Mensagens de voz e texto são recebidas pelo Telegram e enviadas ao provedor escolhido pelo portal (Gemini/Google ou OpenAI) para reconhecimento, com consentimento no vínculo e na troca de provedor. Na faixa gratuita do Gemini, o Google pode usar esse conteúdo para melhorar seus produtos, conforme suas condições. Áudios não são armazenados na mídia do site. Pendências expiram em duas horas; o conteúdo temporário de mensagens é limpo após o processamento ou pela limpeza diária. Identificadores mínimos de entrega podem permanecer por até 90 dias para evitar duplicações. O cron da hospedagem precisa funcionar para processar filas e efetuar as limpezas periódicas. Os dados podem ser exportados e apagados pelas ferramentas de privacidade do WordPress. Excluir uma conta ou atender à sua solicitação de apagamento remove seus veículos e registros e anonimiza a autoria em veículos de terceiros. Desativar ou desinstalar o plugin preserva os dados para reinstalação.</p>' );
            }
        } );
    }

    public static function export( $email, $page = 1 ) {
        global $wpdb;
        $user = get_user_by( 'email', $email );
        if ( ! $user ) { return array( 'data' => array(), 'done' => true ); }
        $page = max( 1, (int) $page ); $data = array();
        if ( 1 === $page ) {
            $vehicles = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}pds_vehicles WHERE owner_user_id = %d", $user->ID ), ARRAY_A );
            foreach ( $vehicles as $vehicle ) {
                $data[] = array( 'group_id' => 'pds-vehicles', 'group_label' => 'Veículos do portal', 'item_id' => 'vehicle-' . $vehicle['id'], 'data' => array( array( 'name' => 'Veículo', 'value' => $vehicle['name'] ), array( 'name' => 'Placa', 'value' => $vehicle['plate'] ) ) );
            }
            $link = PDS_Telegram::link( $user->ID );
            if ( $link ) { $data[] = array( 'group_id' => 'pds-telegram', 'group_label' => 'Telegram do portal', 'item_id' => 'telegram-' . $user->ID, 'data' => array( array( 'name' => 'ID da conta no Telegram', 'value' => (string) $link['telegram_id'] ), array( 'name' => 'Veículo padrão (ID)', 'value' => (string) $link['default_vehicle_id'] ), array( 'name' => 'Provedor autorizado para reconhecimento', 'value' => (string) ( $link['consent_provider'] ?? 'openai' ) ), array( 'name' => 'Confirmar antes de salvar', 'value' => $link['confirm_before_save'] ? 'Sim' : 'Não' ) ) ); }
        }
        if ( 1 === $page ) {
            $categories = $wpdb->get_results( $wpdb->prepare( "SELECT id,name,color,active FROM {$wpdb->prefix}pds_expense_categories WHERE user_id=%d ORDER BY id", $user->ID ), ARRAY_A );
            foreach ( $categories as $c ) { $data[] = array( 'group_id' => 'pds-expense-categories', 'group_label' => 'Categorias de gastos', 'item_id' => 'expense-category-' . $c['id'], 'data' => array( array( 'name' => 'Categoria', 'value' => $c['name'] ), array( 'name' => 'Cor', 'value' => $c['color'] ), array( 'name' => 'Ativa', 'value' => $c['active'] ? 'Sim' : 'Não' ) ) ); }
        }
        $expenses = $wpdb->get_results( $wpdb->prepare( "SELECT e.*,c.name AS category_name FROM {$wpdb->prefix}pds_expenses e INNER JOIN {$wpdb->prefix}pds_expense_categories c ON c.id=e.category_id AND c.user_id=e.user_id WHERE e.user_id=%d ORDER BY e.id LIMIT 100 OFFSET %d", $user->ID, ( $page - 1 ) * 100 ), ARRAY_A );
        foreach ( $expenses as $expense ) { $fields = array(); foreach ( array( 'description' => 'Descrição', 'spent_on' => 'Data', 'amount' => 'Valor em reais', 'category_name' => 'Categoria', 'payment_method' => 'Pagamento', 'merchant' => 'Estabelecimento', 'notes' => 'Observações', 'source' => 'Origem' ) as $key => $label ) { $fields[] = array( 'name' => $label, 'value' => (string) $expense[ $key ] ); } $data[] = array( 'group_id' => 'pds-expenses', 'group_label' => 'Gastos pessoais', 'item_id' => 'expense-' . $expense['id'], 'data' => $fields ); }
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT r.*, v.name AS vehicle_name FROM {$wpdb->prefix}pds_fuel_records r INNER JOIN {$wpdb->prefix}pds_vehicles v ON v.id = r.vehicle_id WHERE v.owner_user_id = %d OR r.created_by = %d ORDER BY r.id LIMIT 100 OFFSET %d", $user->ID, $user->ID, ( $page - 1 ) * 100 ), ARRAY_A );
        foreach ( $rows as $row ) {
            $fields = array();
            foreach ( array( 'vehicle_name' => 'Veículo', 'filled_on' => 'Data', 'odometer' => 'Quilometragem', 'fuel_type' => 'Combustível', 'price' => 'Preço por litro', 'liters' => 'Litros', 'paid' => 'Valor pago', 'full_tank' => 'Tanque completo', 'notes' => 'Observações' ) as $key => $label ) { $fields[] = array( 'name' => $label, 'value' => (string) $row[ $key ] ); }
            $data[] = array( 'group_id' => 'pds-fuel', 'group_label' => 'Abastecimentos do portal', 'item_id' => 'fuel-' . $row['id'], 'data' => $fields );
        }
        $finance_done = true;
        $labels = array( 'name' => 'Nome', 'kind' => 'Tipo', 'opening_balance' => 'Saldo inicial', 'opening_on' => 'Data inicial', 'active' => 'Ativo', 'account_id' => 'Conta (ID)', 'description' => 'Descrição', 'amount' => 'Valor em reais', 'received_on' => 'Data do recebimento', 'status' => 'Situação', 'notes' => 'Observações', 'last_four' => 'Final do cartão', 'credit_limit' => 'Limite', 'closing_day' => 'Dia de fechamento', 'due_day' => 'Dia de vencimento', 'on_close_next' => 'Compra no fechamento vai para próxima fatura', 'card_id' => 'Cartão (ID)', 'invoice_month' => 'Mês de vencimento', 'closing_on' => 'Fechamento', 'due_on' => 'Vencimento', 'expense_id' => 'Compra (ID)', 'invoice_id' => 'Fatura (ID)', 'installment_no' => 'Parcela', 'installment_total' => 'Total de parcelas', 'confirmed' => 'Conferido com a fatura', 'source' => 'Origem', 'due_on' => 'Vencimento previsto', 'first_due' => 'Primeiro vencimento', 'due_day' => 'Dia do vencimento', 'next_month' => 'Próximo mês a gerar', 'end_month' => 'Último mês', 'recurring_id' => 'Recorrência (ID)', 'occurrence_month' => 'Competência da previsão', 'expense_id' => 'Gasto da baixa (ID)', 'paid_on' => 'Data de pagamento', 'from_account_id' => 'Conta de origem (ID)', 'to_account_id' => 'Conta de destino (ID)', 'transferred_on' => 'Data da transferência', 'reversed_at' => 'Registro estornado em (UTC)' );
        foreach ( array( 'transfers' => 'Transferências entre contas', 'payables' => 'Contas a pagar', 'recurring' => 'Recorrências financeiras', 'accounts' => 'Contas financeiras', 'receipts' => 'Recebimentos', 'cards' => 'Cartões', 'invoices' => 'Faturas', 'installments' => 'Parcelas', 'bill_payments' => 'Pagamentos de fatura', 'adjustments' => 'Ajustes de fatura' ) as $table => $label ) {
            $financial = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}pds_fin_{$table} WHERE user_id=%d ORDER BY id LIMIT 100 OFFSET %d", $user->ID, ( $page - 1 ) * 100 ), ARRAY_A );
            foreach ( $financial as $item ) { $fields = array(); foreach ( $labels as $key => $field ) { if ( array_key_exists( $key, $item ) ) { $fields[] = array( 'name' => $field, 'value' => (string) $item[ $key ] ); } } $data[] = array( 'group_id' => 'pds-fin-' . $table, 'group_label' => $label, 'item_id' => $table . '-' . $item['id'], 'data' => $fields ); }
            $finance_done = $finance_done && count( $financial ) < 100;
        }
        return array( 'data' => $data, 'done' => $finance_done && count( $rows ) < 100 && count( $expenses ) < 100 );
    }

    public static function erase( $email, $page = 1 ) {
        $user = get_user_by( 'email', $email );
        if ( ! $user ) { return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true ); }
        return self::cleanup( $user->ID, 100 );
    }

    public static function delete_user( $id ) {
        self::cleanup( (int) $id, 0 );
    }

    private static function cleanup( $id, $limit ) {
        global $wpdb;
        $query = $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}pds_vehicles WHERE owner_user_id = %d", $id );
        if ( $limit ) { $query .= ' LIMIT ' . (int) $limit; }
        $vehicles = $wpdb->get_results( $query, ARRAY_A ); $removed = false; $failed = false;
        foreach ( array( 'pds_tg_drafts', 'pds_tg_updates', 'pds_tg_links', 'pds_tg_expense_drafts', 'pds_tg_receipt_drafts', 'pds_tg_payable_drafts', 'pds_fin_transfers', 'pds_fin_recurring', 'pds_fin_payables', 'pds_fin_installments', 'pds_fin_bill_payments', 'pds_fin_adjustments', 'pds_fin_invoices', 'pds_fin_receipts', 'pds_fin_cards', 'pds_fin_accounts', 'pds_expenses', 'pds_expense_categories' ) as $table ) {
            $deleted = $wpdb->delete( $wpdb->prefix . $table, array( 'user_id' => $id ) );
            $failed = $failed || false === $deleted; $removed = $removed || (bool) $deleted;
        }
        foreach ( $vehicles as $vehicle ) {
            $wpdb->query( 'START TRANSACTION' );
            $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}pds_vehicles WHERE id = %d FOR UPDATE", $vehicle['id'] ) );
            $records = PDS_Fuel::raw_records( $vehicle['id'] );
            foreach ( $records as $record ) {
                $wpdb->delete( $wpdb->prefix . 'pds_import_map', array( 'entity' => 'records', 'target_id' => $record['id'] ) );
                // Preserve the other participant's private financial history when the vehicle owner leaves.
                $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}pds_expenses SET fuel_record_id=NULL WHERE fuel_record_id=%d AND user_id<>%d", $record['id'], $id ) );
            }
            $wpdb->query( $wpdb->prepare( "DELETE m FROM {$wpdb->prefix}pds_import_map m INNER JOIN {$wpdb->prefix}pds_vehicle_shares s ON s.id = m.target_id WHERE m.entity = 'shares' AND s.vehicle_id = %d", $vehicle['id'] ) );
            $wpdb->delete( $wpdb->prefix . 'pds_import_map', array( 'entity' => 'vehicles', 'target_id' => $vehicle['id'] ) );
            $r1 = $wpdb->delete( $wpdb->prefix . 'pds_fuel_records', array( 'vehicle_id' => $vehicle['id'] ) );
            $r2 = $wpdb->delete( $wpdb->prefix . 'pds_vehicle_shares', array( 'vehicle_id' => $vehicle['id'] ) );
            $r3 = $wpdb->delete( $wpdb->prefix . 'pds_vehicles', array( 'id' => $vehicle['id'] ) );
            if ( false === $r1 || false === $r2 || false === $r3 ) { $wpdb->query( 'ROLLBACK' ); $failed = true; continue; }
            $wpdb->query( 'COMMIT' );
            foreach ( $records as $record ) { PDS_Fuel::event( 'deleted', $record, $vehicle ); }
            $removed = true;
        }
        $anonymized = $wpdb->update( $wpdb->prefix . 'pds_fuel_records', array( 'created_by' => 0 ), array( 'created_by' => $id ) );
        $wpdb->query( $wpdb->prepare( "DELETE m FROM {$wpdb->prefix}pds_import_map m INNER JOIN {$wpdb->prefix}pds_vehicle_shares s ON s.id = m.target_id WHERE m.entity = 'shares' AND s.user_id = %d", $id ) );
        $shares = $wpdb->delete( $wpdb->prefix . 'pds_vehicle_shares', array( 'user_id' => $id ) );
        $failed = $failed || false === $anonymized || false === $shares;
        $removed = (bool) $anonymized || (bool) $shares || $removed;
        $done = $failed || ! $limit || count( $vehicles ) < $limit;
        if ( $done && ! $failed ) {
            $wpdb->delete( $wpdb->prefix . 'pds_import_map', array( 'entity' => 'users', 'target_id' => $id ) );
            $job = get_user_meta( $id, 'pds_import_active_job', true );
            if ( is_string( $job ) && preg_match( '/^[a-f0-9]{32}$/D', $job ) ) { delete_transient( 'pds_import_job_' . $job ); }
            $previews = get_user_meta( $id, 'pds_fin_import_jobs', true ); if ( is_array( $previews ) ) { foreach ( $previews as $hash ) { if ( is_string( $hash ) && preg_match( '/^[a-f0-9]{64}$/D', $hash ) ) { delete_transient( 'pds_fin_preview_' . $hash ); delete_option( 'pds_fin_import_lock_' . $hash ); } } } delete_user_meta( $id, 'pds_fin_import_jobs' );
            foreach ( array( 'pds_member', 'pds_suspended', 'pds_blocked_services', 'pds_policy_accepted_at', 'pds_import_password_reset', 'pds_import_active_job', 'pds_expenses_seeded' ) as $key ) { delete_user_meta( $id, $key ); }
        }
        return array( 'items_removed' => $removed, 'items_retained' => $failed, 'messages' => $failed ? array( 'Alguns dados não puderam ser apagados. Verifique o banco do portal e tente novamente.' ) : array(), 'done' => $done );
    }
}
